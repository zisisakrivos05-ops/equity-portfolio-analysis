"""Unit tests (run with `pytest` or `python tests/test_core.py`)."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from eqport.config import Config
from eqport.momentum import decile_portfolios, momentum_signal
from eqport.optimization import rolling_oos, tangency_weights
from eqport.stats import grs_test, market_proxy, ols_capm


def _panel(n=40, t=180, seed=0):
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2005-01-31", periods=t, freq="ME")
    mkt = rng.normal(0.006, 0.04, t)
    beta = rng.uniform(0.6, 1.4, n)
    R = pd.DataFrame(np.outer(mkt, beta) + rng.normal(0, 0.05, (t, n)), index=idx,
                     columns=[f"S{i}" for i in range(n)])
    mc = pd.DataFrame(rng.uniform(1, 10, (t, n)), index=idx, columns=R.columns)
    return R, mc


def test_ols_recovers_parameters():
    rng = np.random.default_rng(1)
    x = pd.Series(rng.normal(0, 0.04, 2000))
    y = 0.002 + 1.3 * x + pd.Series(rng.normal(0, 0.01, 2000))
    res = ols_capm(y, x)
    assert abs(res["alpha"] - 0.002) < 5e-4 and abs(res["beta"] - 1.3) < 0.02


def test_tangency_weights_sum_to_one_and_long_only_nonnegative():
    R, _ = _panel()
    for lo in (False, True):
        w = tangency_weights(R.mean(), R.cov(), 0.0025, long_only=lo)
        assert abs(w.sum() - 1) < 1e-8
        if lo:
            assert (w >= -1e-9).all()


def test_market_proxy_has_no_lookahead():
    R, mc = _panel()
    base = market_proxy(R, mc)
    mc2 = mc.copy()
    mc2.iloc[-1] *= 100            # changing the last month's cap must not alter any return
    assert np.allclose(base, market_proxy(R, mc2), equal_nan=True)


def test_momentum_signal_skips_recent_month():
    R, _ = _panel()
    sig = momentum_signal(R, 12, 1)
    t = 50
    expected = np.log1p(R.iloc[t - 12: t - 1]).sum()       # months t-12 .. t-2
    assert np.allclose(sig.iloc[t], expected)


def test_momentum_uses_only_past_data():
    R, _ = _panel()
    cfg = Config()
    P1 = decile_portfolios(R, cfg)
    R2 = R.copy()
    R2.iloc[-1] = 0.5               # perturb final month's returns
    P2 = decile_portfolios(R2, cfg)
    assert np.allclose(P1.iloc[:-1], P2.iloc[:-1], equal_nan=True)


def test_oos_runs_and_starts_after_first_window():
    R, _ = _panel(t=200)
    cfg = Config()
    oos, wh = rolling_oos(R, cfg, long_only=True)
    assert oos.index.min() > R.index[cfg.window_years * 12 - 1]
    assert len(wh) >= 1 and oos.notna().all()


def test_grs_does_not_reject_under_true_capm():
    rng = np.random.default_rng(3)
    t, n = 600, 10
    idx = pd.date_range("1970-01-31", periods=t, freq="ME")
    mkt = pd.Series(rng.normal(0.006, 0.04, t), index=idx)
    R = pd.DataFrame(np.outer(mkt, rng.uniform(0.7, 1.3, n)) + rng.normal(0, 0.03, (t, n)), index=idx)
    res = grs_test(R, pd.Series(0.0, index=idx), mkt)
    assert res["p_value"] > 0.01


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
