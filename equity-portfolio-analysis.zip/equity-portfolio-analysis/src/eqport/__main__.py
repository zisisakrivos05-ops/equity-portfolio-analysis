"""Command line interface:  python -m eqport --data data/file.xlsx   |   python -m eqport --demo"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .config import Config
from .data import load_dataset
from .pipeline import run


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="eqport", description="Equity portfolio analysis toolkit.")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--data", type=Path, help="Excel file with sheets STOCKS, market_cap, returns")
    src.add_argument("--demo", action="store_true", help="run on generated synthetic data")
    ap.add_argument("--out", type=Path, default=Path("results"), help="output directory")
    ap.add_argument("--rf", type=float, default=Config.rf_annual, help="annual risk-free rate")
    ap.add_argument("--n-stocks", type=int, default=Config.n_stocks)
    ap.add_argument("--window-years", type=int, default=Config.window_years)
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(levelname)s | %(message)s")
    cfg = Config(rf_annual=args.rf, n_stocks=args.n_stocks, window_years=args.window_years)

    data_path = args.data
    if args.demo:
        sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
        from scripts.make_synthetic_data import make_synthetic
        data_path = make_synthetic(Path("data/synthetic.xlsx"))

    summary = run(load_dataset(data_path, cfg), cfg, args.out)
    logging.info("Done. Outputs written to %s", args.out)
    q = summary["q5_momentum"]
    logging.info("Tangency in-sample Sharpe: %.2f | GRS p-value: %.3f | WML mean: %.2f%%/month",
                 summary["q2_tangency_in_sample"]["sharpe_ann"], summary["q2_grs"]["p_value"],
                 q["wml_mean_monthly"] * 100)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
