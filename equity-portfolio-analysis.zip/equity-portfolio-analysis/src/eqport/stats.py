"""Descriptive statistics, OLS/CAPM regressions and the GRS test."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats as sps


def descriptive_stats(R: pd.DataFrame, rf_monthly: float) -> pd.DataFrame:
    """Per-stock summary statistics (monthly and annualised)."""
    out = pd.DataFrame({
        "mean": R.mean(), "std": R.std(), "var": R.var(),
        "min": R.min(), "max": R.max(),
        "skew": R.skew(), "kurt": R.kurt(), "n_obs": R.notna().sum(),
    })
    out["ann_mean"] = out["mean"] * 12
    out["ann_std"] = out["std"] * np.sqrt(12)
    out["sharpe_ann"] = (out["mean"] - rf_monthly) / out["std"] * np.sqrt(12)
    return out.sort_values("mean", ascending=False)


def mean_pairwise_corr(corr: pd.DataFrame) -> float:
    return float(corr.values[np.triu_indices_from(corr.values, k=1)].mean())


def market_proxy(R: pd.DataFrame, mcap: pd.DataFrame) -> pd.Series:
    """Value-weighted market return using *lagged* market caps (no look-ahead).

    Weights are renormalised each month over the stocks that actually have a return.
    """
    w = mcap.reindex(index=R.index, columns=R.columns).shift(1).where(R.notna())
    w = w.div(w.sum(axis=1), axis=0)
    return (w * R).sum(axis=1, min_count=1).rename("market")


def ols_capm(y: pd.Series, x: pd.Series, min_obs: int = 24) -> dict[str, float]:
    """OLS of excess return y on excess market return x, with classical t-stats."""
    df = pd.concat([y, x], axis=1).dropna()
    n = len(df)
    nan = {k: np.nan for k in ("alpha", "beta", "t_alpha", "t_beta", "r2", "n_obs")}
    if n < min_obs:
        return {**nan, "n_obs": n}
    yv, xv = df.iloc[:, 0].to_numpy(), df.iloc[:, 1].to_numpy()
    X = np.column_stack([np.ones(n), xv])
    b, *_ = np.linalg.lstsq(X, yv, rcond=None)
    resid = yv - X @ b
    sigma2 = resid @ resid / (n - 2)
    se = np.sqrt(np.diag(sigma2 * np.linalg.inv(X.T @ X)))
    ss_tot = ((yv - yv.mean()) ** 2).sum()
    return {
        "alpha": b[0], "beta": b[1], "t_alpha": b[0] / se[0], "t_beta": b[1] / se[1],
        "r2": 1 - resid @ resid / ss_tot if ss_tot > 0 else np.nan, "n_obs": n,
    }


def capm_table(R: pd.DataFrame, rf: pd.Series, mkt: pd.Series, min_obs: int = 24) -> pd.DataFrame:
    """Run the time-series CAPM regression for every column of R."""
    mkt_ex = mkt - rf
    rows = {c: ols_capm(R[c] - rf, mkt_ex, min_obs) for c in R.columns}
    out = pd.DataFrame(rows).T
    out["alpha_ann_pct"] = out["alpha"] * 12 * 100
    return out


def grs_test(R: pd.DataFrame, rf: pd.Series, mkt: pd.Series) -> dict[str, float]:
    """Gibbons-Ross-Shanken (1989) joint test that all CAPM alphas are zero.

    F = (T-N-1)/N * a' S^-1 a / (1 + SR_m^2),  F ~ F(N, T-N-1) under H0,
    with S the MLE residual covariance. Requires a balanced panel (no missing values),
    so only stocks with complete history over the common sample are used.
    """
    panel = pd.concat([R.sub(rf, axis=0), (mkt - rf).rename("__mkt__")], axis=1)
    panel = panel.dropna(axis=1, thresh=int(0.999 * len(panel)))   # keep (almost) complete columns
    panel = panel.dropna(axis=0)
    assets = [c for c in panel.columns if c != "__mkt__"]
    T, N = len(panel), len(assets)
    if N == 0 or T <= N + 1:
        return {"F": np.nan, "p_value": np.nan, "N": N, "T": T}

    Y, x = panel[assets].to_numpy(), panel["__mkt__"].to_numpy()
    X = np.column_stack([np.ones(T), x])
    B, *_ = np.linalg.lstsq(X, Y, rcond=None)              # (2, N)
    E = Y - X @ B
    Sigma = E.T @ E / T                                    # MLE
    a = B[0]
    sr2 = x.mean() ** 2 / x.var()                          # squared market Sharpe (MLE var)
    F = (T - N - 1) / N * float(a @ np.linalg.pinv(Sigma) @ a) / (1 + sr2)
    return {"F": F, "p_value": float(sps.f.sf(F, N, T - N - 1)), "N": N, "T": T}
