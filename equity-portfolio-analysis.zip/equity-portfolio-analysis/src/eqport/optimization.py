"""Mean-variance optimisation and rolling out-of-sample backtests."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .config import Config

log = logging.getLogger(__name__)


def tangency_weights(mu: pd.Series, cov: pd.DataFrame, rf: float,
                     long_only: bool = False) -> pd.Series:
    """Maximum-Sharpe (tangency) portfolio, weights summing to 1.

    - unconstrained: closed form  w ∝ Σ^-1 (μ - rf)   (shorting allowed)
    - long_only:     numerical max-Sharpe with w >= 0 (SLSQP)
    Falls back to equal weights if the problem is degenerate.
    """
    n = len(mu)
    ex = (mu - rf).to_numpy()
    S = cov.to_numpy()
    equal = pd.Series(np.full(n, 1.0 / n), index=mu.index)

    if not long_only:
        raw = np.linalg.pinv(S) @ ex
        total = raw.sum()
        if not np.isfinite(total) or total <= 1e-10:
            log.warning("Degenerate tangency solution (sum of raw weights <= 0); using 1/N.")
            return equal
        return pd.Series(raw / total, index=mu.index)

    def neg_sharpe(w: np.ndarray) -> float:
        var = w @ S @ w
        return -(w @ ex) / np.sqrt(max(var, 1e-16))

    res = minimize(neg_sharpe, np.full(n, 1.0 / n), method="SLSQP",
                   bounds=[(0.0, 1.0)] * n,
                   constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1.0}],
                   options={"maxiter": 500, "ftol": 1e-10})
    if not res.success or not np.all(np.isfinite(res.x)):
        log.warning("Long-only optimiser did not converge (%s); using 1/N.", res.message)
        return equal
    w = np.clip(res.x, 0, None)
    return pd.Series(w / w.sum(), index=mu.index)


def portfolio_summary(r: pd.Series, rf_monthly: float) -> dict[str, float]:
    """Annualised performance summary of a monthly return series."""
    r = r.dropna()
    cum = (1 + r).cumprod()
    return {
        "mean_monthly": r.mean(), "std_monthly": r.std(),
        "ann_mean": r.mean() * 12, "ann_std": r.std() * np.sqrt(12),
        "sharpe_ann": (r.mean() - rf_monthly) / r.std() * np.sqrt(12),
        "min": r.min(), "max": r.max(), "skew": r.skew(), "kurt": r.kurt(),
        "max_drawdown": float((cum / cum.cummax() - 1).min()),
        "n_months": int(len(r)),
    }


def rolling_oos(R: pd.DataFrame, cfg: Config, long_only: bool = False
                ) -> tuple[pd.Series, dict[pd.Timestamp, pd.Series]]:
    """Out-of-sample tangency portfolio with rolling estimation window.

    At each rebalance date t (cfg.rebalance_month) the portfolio is estimated on the
    trailing window ending at t (using only stocks with a *complete* window) and then held
    until the next rebalance date, with weights drifting with realised returns
    (buy-and-hold between rebalances). A missing return after the estimation date
    (delisting) is treated as 0%.
    """
    W = cfg.window_years * 12
    dates = R.index
    rebal_idx = [i for i, d in enumerate(dates) if d.month == cfg.rebalance_month and i >= W - 1]
    if not rebal_idx:
        raise ValueError("Not enough history for the requested estimation window.")

    out, weights_hist = [], {}
    for k, i in enumerate(rebal_idx):
        window = R.iloc[i - W + 1: i + 1]
        window = window.loc[:, window.notna().all()]
        if window.shape[1] < 2:
            continue
        w = tangency_weights(window.mean(), window.cov(), cfg.rf_monthly, long_only)
        weights_hist[dates[i]] = w

        end = rebal_idx[k + 1] if k + 1 < len(rebal_idx) else len(dates) - 1
        cur = w.copy()
        for j in range(i + 1, end + 1):
            r = R.iloc[j][cur.index].fillna(0.0)
            pr = float(cur @ r)
            out.append((dates[j], pr))
            cur = cur * (1 + r) / (1 + pr)          # weights drift between rebalances

    oos = pd.Series(dict(out), name="oos_long_only" if long_only else "oos_unconstrained")
    return oos.sort_index(), weights_hist
