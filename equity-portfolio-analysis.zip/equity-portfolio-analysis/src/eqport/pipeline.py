"""End-to-end analysis: descriptive stats -> tangency + CAPM/GRS -> OOS backtest -> momentum."""
from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np
import pandas as pd

from . import plots
from .config import Config
from .data import Dataset
from .momentum import decile_portfolios, momentum_summary
from .optimization import portfolio_summary, rolling_oos, tangency_weights
from .stats import capm_table, descriptive_stats, grs_test, market_proxy, mean_pairwise_corr

log = logging.getLogger(__name__)


def run(ds: Dataset, cfg: Config, out_dir: Path) -> dict:
    out_dir = Path(out_dir)
    fig_dir = out_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)

    R, mcap = ds.returns, ds.mcap
    rf = pd.Series(cfg.rf_monthly, index=R.index, name="rf")
    mkt = market_proxy(R, mcap)
    summary: dict = {"n_stocks": R.shape[1], "n_months": len(R),
                     "start": str(R.index.min().date()), "end": str(R.index.max().date()),
                     "rf_monthly": cfg.rf_monthly}

    # ---- 1. Descriptive statistics ------------------------------------------------------
    log.info("1/4 Descriptive statistics")
    stats = descriptive_stats(R, cfg.rf_monthly)
    corr = R.corr()
    mean_corr = mean_pairwise_corr(corr)
    stats.to_csv(out_dir / "q1_descriptive.csv")
    R.cov().to_csv(out_dir / "q1_covariance.csv")
    corr.to_csv(out_dir / "q1_correlation.csv")
    plots.plot_descriptive(stats, corr, mean_corr, fig_dir / "q1_descriptive.png")
    summary["q1"] = {"avg_mean_monthly": R.mean().mean(), "avg_std_monthly": R.std().mean(),
                     "avg_pairwise_corr": mean_corr}

    # ---- 2. Tangency portfolio + CAPM + GRS ---------------------------------------------
    log.info("2/4 Tangency portfolio, CAPM and GRS test")
    full = R.loc[:, R.notna().sum() >= cfg.min_obs]
    w_tan = tangency_weights(full.mean(), full.cov(), cfg.rf_monthly)       # pairwise-complete moments
    port = (full.fillna(0.0) * w_tan).sum(axis=1)
    summary["q2_tangency_in_sample"] = portfolio_summary(port, cfg.rf_monthly)
    w_tan.sort_values(ascending=False).to_csv(out_dir / "q2_tangency_weights.csv", header=["weight"])

    capm = capm_table(R, rf, mkt, cfg.min_obs)
    capm.to_csv(out_dir / "q2_capm_per_stock.csv")
    grs = grs_test(R, rf, mkt)
    summary["q2_capm"] = {
        "mean_alpha_monthly": capm["alpha"].mean(), "mean_beta": capm["beta"].mean(),
        "mean_r2": capm["r2"].mean(),
        "n_sig_alpha_5pct": int((capm["t_alpha"].abs() > 1.96).sum()), "n_regressions": len(capm),
    }
    summary["q2_grs"] = grs
    plots.plot_sml(capm, R, mkt, cfg.rf_monthly, fig_dir / "q2_sml.png")

    # ---- 3. Out-of-sample rolling optimisation ------------------------------------------
    log.info("3/4 Out-of-sample backtest (%d-year window)", cfg.window_years)
    oos_u, _ = rolling_oos(R, cfg, long_only=False)
    oos_l, wh = rolling_oos(R, cfg, long_only=True)
    ew = R.reindex(oos_u.index).mean(axis=1).rename("equal_weight")
    oos = pd.concat([oos_u, oos_l, ew], axis=1)
    oos.to_csv(out_dir / "q4_oos_returns.csv")
    summary["q4_oos"] = {c: portfolio_summary(oos[c], cfg.rf_monthly) for c in oos.columns}
    summary["q4_oos"]["n_rebalances"] = len(wh)
    plots.plot_oos({"Tangency (unconstrained)": oos_u, "Tangency (long-only)": oos_l,
                    "Equal-weighted (1/N)": ew}, fig_dir / "q4_oos_cumulative.png")

    # ---- 4. Momentum ---------------------------------------------------------------------
    log.info("4/4 Momentum deciles")
    P = decile_portfolios(R, cfg)
    P.to_csv(out_dir / "q5_momentum_portfolio_returns.csv")
    mom, wml, tests = momentum_summary(P, mkt, rf, cfg.min_obs)
    mom.to_csv(out_dir / "q5_momentum_summary.csv")
    summary["q5_momentum"] = {**tests, "wml_mean_monthly": wml.mean(),
                              "wml_alpha_monthly": mom.loc["WML", "alpha"],
                              "wml_t_alpha": mom.loc["WML", "t_alpha"],
                              "wml_beta": mom.loc["WML", "beta"]}
    plots.plot_momentum(mom, cfg.n_deciles, fig_dir / "q5_momentum.png")

    def _clean(o):
        if isinstance(o, dict):
            return {k: _clean(v) for k, v in o.items()}
        if isinstance(o, (np.floating, float)):
            return None if not np.isfinite(o) else float(o)
        if isinstance(o, np.integer):
            return int(o)
        return o

    (out_dir / "summary.json").write_text(json.dumps(_clean(summary), indent=2))
    return summary
