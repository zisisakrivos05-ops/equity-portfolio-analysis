"""eqport: equity portfolio analysis toolkit (descriptive stats, mean-variance
optimisation, CAPM/GRS tests, out-of-sample backtests and momentum sorts)."""

__version__ = "1.0.0"
