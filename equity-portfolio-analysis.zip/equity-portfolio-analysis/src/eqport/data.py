"""Data loading and universe selection."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from .config import Config

log = logging.getLogger(__name__)


@dataclass
class Dataset:
    returns: pd.DataFrame      # monthly simple returns (decimal), index = month, columns = tickers
    mcap: pd.DataFrame         # monthly market capitalisation, same shape as `returns`
    info: pd.DataFrame         # static metadata (name, country, sector, ...)


def _read_panel(path: Path, sheet: str) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name=sheet, index_col=0, engine="openpyxl")
    df.index = pd.to_datetime(df.index, errors="coerce", dayfirst=True)
    df = df[~df.index.isna()].apply(pd.to_numeric, errors="coerce")
    return df.sort_index()


def _find_sheet(names: list[str], wanted: str) -> str:
    """Case/whitespace-insensitive sheet lookup (the raw file has a sheet called ' returns')."""
    for name in names:
        if name.strip().lower() == wanted.lower():
            return name
    raise KeyError(f"Sheet '{wanted}' not found. Available sheets: {names}")


def load_dataset(path: str | Path, cfg: Config) -> Dataset:
    """Load returns / market caps / metadata and keep the `cfg.n_stocks` largest stocks."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(
            f"Data file not found: {path}\n"
            "Pass --data /path/to/file.xlsx, or run with --demo to use synthetic data."
        )

    names = pd.ExcelFile(path, engine="openpyxl").sheet_names
    returns = _read_panel(path, _find_sheet(names, "returns"))
    mcap = _read_panel(path, _find_sheet(names, "market_cap"))
    info = pd.read_excel(path, sheet_name=_find_sheet(names, "stocks"), engine="openpyxl")
    info.columns = [str(c).strip() for c in info.columns]

    common = returns.columns.intersection(mcap.columns)
    returns, mcap = returns[common], mcap[common]

    if returns.shape[1] > cfg.n_stocks:
        keep = mcap.mean().nlargest(cfg.n_stocks).index
        returns, mcap = returns[keep], mcap[keep]

    returns = returns.dropna(how="all")
    mcap = mcap.reindex(returns.index)

    coverage = returns.notna().mean()
    log.info("Universe: %d stocks, %d months (%s -> %s)", returns.shape[1], returns.shape[0],
             returns.index.min().date(), returns.index.max().date())
    log.info("Data coverage per stock: min=%.0f%% median=%.0f%% max=%.0f%%",
             coverage.min() * 100, coverage.median() * 100, coverage.max() * 100)
    return Dataset(returns=returns, mcap=mcap, info=info)
