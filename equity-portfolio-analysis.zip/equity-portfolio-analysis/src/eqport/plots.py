"""Figures (headless-safe)."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams.update({"figure.dpi": 110, "savefig.dpi": 150, "axes.grid": True, "grid.alpha": 0.3,
                     "axes.spines.top": False, "axes.spines.right": False})
BLUE, RED, GREY = "#2b6cb0", "#c53030", "#718096"


def _save(fig, path: Path) -> None:
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def plot_descriptive(stats: pd.DataFrame, corr: pd.DataFrame, mean_corr: float, path: Path) -> None:
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].hist(stats["mean"] * 100, bins=15, color=BLUE, edgecolor="white")
    ax[0].set(title="Distribution of mean monthly returns", xlabel="Mean monthly return (%)",
              ylabel="Number of stocks")
    im = ax[1].imshow(corr.values, cmap="RdBu_r", vmin=-1, vmax=1)
    ax[1].set_title(f"Correlation matrix (average pairwise ρ = {mean_corr:.2f})")
    ax[1].grid(False)
    fig.colorbar(im, ax=ax[1], fraction=0.046)
    _save(fig, path)


def plot_sml(capm: pd.DataFrame, R: pd.DataFrame, mkt: pd.Series, rf_m: float, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(capm["beta"], R.mean() * 12 * 100, s=32, alpha=0.75, color=BLUE,
               edgecolor="navy", label="Stocks")
    b = np.linspace(capm["beta"].min() - 0.1, capm["beta"].max() + 0.1, 50)
    ax.plot(b, (rf_m + b * (mkt.mean() - rf_m)) * 12 * 100, "--", color=RED, lw=2, label="SML (CAPM)")
    ax.set(xlabel="Market beta", ylabel="Mean annual return (%)", title="Security Market Line")
    ax.legend()
    _save(fig, path)


def plot_oos(series: dict[str, pd.Series], path: Path) -> None:
    fig, ax = plt.subplots(figsize=(9, 4.5))
    styles = {"Tangency (unconstrained)": (BLUE, "-"), "Tangency (long-only)": ("#2f855a", "-"),
              "Equal-weighted (1/N)": (GREY, "--")}
    for name, s in series.items():
        c, ls = styles.get(name, (None, "-"))
        ax.plot(s.index, (1 + s).cumprod(), label=name, color=c, ls=ls, lw=2)
    ax.set(ylabel="Growth of 1 (log scale)", yscale="log",
           title="Out-of-sample cumulative performance (rolling window, annual rebalancing)")
    ax.legend()
    _save(fig, path)


def plot_momentum(summary: pd.DataFrame, n: int, path: Path) -> None:
    deciles = [f"P{i + 1}" for i in range(n)]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
    ax[0].bar(range(1, n + 1), summary.loc[deciles, "ann_mean"].astype(float) * 100,
              color=BLUE, edgecolor="white")
    ax[0].set(xlabel="Momentum decile (1 = losers, 10 = winners)", ylabel="Mean annual return (%)",
              title="Mean return by momentum decile", xticks=range(1, n + 1))
    alpha = summary.loc[deciles, "alpha_ann_pct"].astype(float)
    ax[1].bar(range(1, n + 1), alpha, color=[("#2f855a" if a > 0 else RED) for a in alpha],
              edgecolor="white")
    ax[1].axhline(0, color="black", lw=0.6)
    ax[1].set(xlabel="Momentum decile", ylabel="CAPM alpha (annualised %)",
              title="CAPM alpha by momentum decile", xticks=range(1, n + 1))
    _save(fig, path)
