"""Central configuration for the analysis."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    # Universe
    n_stocks: int = 50                # keep the N largest stocks by average market cap
    min_obs: int = 36                 # minimum monthly observations to estimate a stock-level model

    # Risk-free rate (constant, annual). The dataset ships no reliable rf series.
    rf_annual: float = 0.03

    # Out-of-sample backtest
    window_years: int = 5             # rolling estimation window
    rebalance_month: int = 12         # rebalance every December

    # Momentum (Jegadeesh-Titman / Carhart style 12-1)
    mom_lookback: int = 12            # months of history used in the signal
    mom_skip: int = 1                 # most recent month(s) skipped (short-term reversal)
    n_deciles: int = 10

    @property
    def rf_monthly(self) -> float:
        """Geometric monthly equivalent of the annual risk-free rate."""
        return (1.0 + self.rf_annual) ** (1.0 / 12.0) - 1.0
