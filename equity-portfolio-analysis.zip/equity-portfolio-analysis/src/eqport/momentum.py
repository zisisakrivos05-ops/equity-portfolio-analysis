"""Momentum (12-1) decile portfolios and the winners-minus-losers (WML) spread."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats as sps

from .config import Config
from .stats import ols_capm


def momentum_signal(R: pd.DataFrame, lookback: int = 12, skip: int = 1) -> pd.DataFrame:
    """Cumulative (log) return over months t-lookback ... t-skip-1, known at the start of month t.

    With the defaults (12-1) the signal for month t uses returns from t-12 to t-2 (11 months),
    skipping month t-1 to avoid the short-term reversal effect. A stock needs a *complete*
    window to receive a signal (no zero-filling of missing data).
    """
    window = lookback - skip
    log_r = np.log1p(R)
    return log_r.rolling(window, min_periods=window).sum().shift(skip + 1)


def decile_portfolios(R: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    """Equal-weighted portfolios P1 (losers) ... P{n} (winners), rebalanced monthly."""
    sig = momentum_signal(R, cfg.mom_lookback, cfg.mom_skip)
    n = cfg.n_deciles
    cols = [f"P{i + 1}" for i in range(n)]
    out = pd.DataFrame(np.nan, index=R.index, columns=cols)

    for date, s in sig.iterrows():
        s = s.dropna()
        if len(s) < n:
            continue
        # rank(method="first") breaks ties deterministically so every decile is populated
        bucket = pd.qcut(s.rank(method="first"), n, labels=False)
        rets = R.loc[date, s.index]
        for i in range(n):
            members = rets[bucket == i]
            if members.notna().any():
                out.loc[date, cols[i]] = members.mean()
    return out.dropna(how="all")


def momentum_summary(P: pd.DataFrame, mkt: pd.Series, rf: pd.Series, min_obs: int = 24
                     ) -> tuple[pd.DataFrame, pd.Series, dict[str, float]]:
    """Per-decile CAPM stats, the WML series and the monotonicity (Spearman) test."""
    rf = rf.reindex(P.index)
    mkt_ex = (mkt - rf.reindex(mkt.index)).reindex(P.index)

    rows = {}
    for c in P.columns:
        capm = ols_capm(P[c] - rf, mkt_ex, min_obs)
        rows[c] = {
            "mean_monthly": P[c].mean(), "std_monthly": P[c].std(),
            "ann_mean": P[c].mean() * 12, "ann_std": P[c].std() * np.sqrt(12),
            "sharpe_ann": (P[c] - rf).mean() / P[c].std() * np.sqrt(12), **capm,
        }
    summary = pd.DataFrame(rows).T

    # WML is a zero-cost long-short strategy, so it is regressed on the market excess return
    # without subtracting rf from the spread.
    wml = (P.iloc[:, -1] - P.iloc[:, 0]).rename("WML")
    capm = ols_capm(wml, mkt_ex, min_obs)
    t_mean = wml.mean() / (wml.std() / np.sqrt(wml.notna().sum()))
    summary.loc["WML"] = {
        "mean_monthly": wml.mean(), "std_monthly": wml.std(),
        "ann_mean": wml.mean() * 12, "ann_std": wml.std() * np.sqrt(12),
        "sharpe_ann": wml.mean() / wml.std() * np.sqrt(12), **capm,
    }
    summary["alpha_ann_pct"] = summary["alpha"] * 12 * 100

    rho, p = sps.spearmanr(np.arange(1, len(P.columns) + 1), summary.loc[P.columns, "mean_monthly"])
    tests = {"spearman_rho": float(rho), "spearman_p": float(p), "wml_mean_t_stat": float(t_mean)}
    return summary, wml, tests
