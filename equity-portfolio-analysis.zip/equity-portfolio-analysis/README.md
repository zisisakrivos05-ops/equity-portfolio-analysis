# Equity Portfolio Analysis

A reproducible Python toolkit for empirical asset-pricing and portfolio analysis on a
monthly panel of 50 stocks. It covers the classic workflow from descriptive statistics to
mean-variance optimisation, CAPM/GRS testing, out-of-sample backtesting and momentum sorts.

> Originally written for the *Intelligent Methods for Financial Data Analysis* course (2026),
> then refactored into a tested, modular package.

## What it does

| Step | Analysis | Method |
|------|----------|--------|
| 1 | **Descriptive statistics** | Mean, volatility, skewness, kurtosis, Sharpe, covariance and correlation matrices |
| 2 | **Tangency portfolio + CAPM** | Closed-form max-Sharpe weights; per-stock CAPM regressions; joint **GRS test** (Gibbons-Ross-Shanken, 1989) with exact F p-value |
| 3 | **Out-of-sample backtest** | 5-year rolling window, annual rebalancing, weights drift between rebalances. Compares unconstrained tangency, long-only tangency and 1/N |
| 4 | **Momentum (12-1)** | 10 equal-weighted decile portfolios, CAPM alphas, winners-minus-losers (WML) spread, Spearman monotonicity test |

## Quick start

```bash
git clone https://github.com/<you>/equity-portfolio-analysis.git
cd equity-portfolio-analysis
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Run on generated synthetic data (no private data needed)
PYTHONPATH=src python -m eqport --demo

# Or on your own file
PYTHONPATH=src python -m eqport --data data/your_file.xlsx --rf 0.03 --window-years 5
```

Outputs (CSV tables, `summary.json`, PNG figures) are written to `results/`.

### Input format
An Excel workbook with three sheets: `STOCKS` (metadata), `market_cap` and `returns`
(dates in the first column, one column per ticker, returns as decimals, e.g. `0.05` = 5%).

## Project layout

```
src/eqport/
  data.py          loading + universe selection (top-N by average market cap)
  stats.py         descriptive stats, value-weighted market proxy, OLS/CAPM, GRS test
  optimization.py  tangency portfolio (unconstrained / long-only), rolling OOS backtest
  momentum.py      12-1 signal, decile portfolios, WML, rank test
  plots.py         figures
  pipeline.py      end-to-end orchestration
scripts/make_synthetic_data.py   synthetic dataset generator
tests/test_core.py               unit tests (look-ahead, estimators, optimiser)
```

Run the tests with `pytest` (or `python tests/test_core.py`).

## Methodological notes

- **No look-ahead.** Market weights use lagged market caps, momentum signals use only past
  returns (month *t-1* is skipped), and the OOS portfolio is estimated on data up to the
  rebalance date and traded afterwards. Tests assert this explicitly.
- **Missing data is not zero-filled** when estimating moments or signals. Stocks need a complete
  window to enter an optimisation or a momentum ranking; the GRS test uses a balanced sub-panel.
- **Risk-free rate** is a constant 3% p.a. (about 0.247% per month) because the dataset has no
  reliable series. Change it with `--rf`.
- **Unconstrained mean-variance weights are noisy** with 50 assets and 60 observations, which
  is why a long-only variant and a 1/N benchmark are reported next to it (estimation error is
  the usual reason 1/N is hard to beat out of sample).
- Standard errors are classical OLS (no Newey-West); the sample is a 50-stock sub-universe, so
  results are illustrative rather than a statement about the whole market.

## Demo output (synthetic data)

These figures come from `--demo` data, **not** real market data.

![OOS](docs/q4_oos_cumulative.png)
![SML](docs/q2_sml.png)
![Momentum](docs/q5_momentum.png)

## License
MIT
