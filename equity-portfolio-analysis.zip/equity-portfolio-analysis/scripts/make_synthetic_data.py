"""Generate a synthetic dataset with the same Excel layout as the real one.

Lets anyone run the full pipeline without the (private) course dataset.
Returns follow a one-factor model plus a small momentum-like persistence component.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def make_synthetic(path: Path, n_stocks: int = 60, n_months: int = 240, seed: int = 42) -> Path:
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2005-01-31", periods=n_months, freq="ME")
    tickers = [f"STOCK_{i:02d}" for i in range(n_stocks)]

    market = rng.normal(0.007, 0.04, n_months)
    beta = rng.uniform(0.5, 1.5, n_stocks)
    alpha = rng.normal(0.0, 0.002, n_stocks)
    idio = rng.normal(0.0, 0.06, (n_months, n_stocks))
    R = alpha + np.outer(market, beta) + idio
    # mild return persistence so the momentum sort has something to find
    R[1:] += 0.05 * R[:-1]
    R = pd.DataFrame(R, index=dates, columns=tickers)

    # a few stocks listed late / delisted early -> unbalanced panel
    for k in rng.choice(n_stocks, 8, replace=False):
        start, stop = rng.integers(0, 60), rng.integers(n_months - 40, n_months)
        R.iloc[:start, k] = np.nan
        R.iloc[stop:, k] = np.nan

    size0 = rng.lognormal(8, 1, n_stocks)
    mcap = pd.DataFrame(size0 * (1 + R.fillna(0)).cumprod().to_numpy(), index=dates, columns=tickers)
    mcap = mcap.where(R.notna())

    info = pd.DataFrame({
        "FULL NAME": tickers,
        "COUNTRY": rng.choice(["US", "DE", "FR", "GB", "JP"], n_stocks),
        "ECONOMIC SECTOR": rng.choice(["Technology", "Financials", "Energy", "Health Care"], n_stocks),
        "CURRENCY": "EUR",
    })

    path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        info.to_excel(xw, sheet_name="STOCKS", index=False)
        mcap.to_excel(xw, sheet_name="market_cap")
        R.to_excel(xw, sheet_name=" returns")        # leading space mirrors the real file
    return path


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", type=Path, default=Path("data/synthetic.xlsx"))
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    print(f"Wrote {make_synthetic(args.out, seed=args.seed)}")
